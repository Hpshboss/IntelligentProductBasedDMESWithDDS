cp -r */* .

fastrtpsgen *.idl

cmake .

make